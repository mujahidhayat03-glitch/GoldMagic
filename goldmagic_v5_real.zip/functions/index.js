const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.database();

// Profit every 2 hours (real)
exports.applyProfitEvery2Hours = functions.pubsub.schedule("every 2 hours").onRun(async (context) => {
  const usersSnap = await db.ref("users").once("value");
  usersSnap.forEach(userSnap => {
    let balance = userSnap.child("balance").val() || 0;
    let profit = balance * 0.02;
    db.ref("users/"+userSnap.key+"/balance").set(balance + profit);
    const txRef=db.ref("transactions/"+userSnap.key).push();
    txRef.set({type:"profit", amount:profit, time:Date.now()});
  });
  return null;
});